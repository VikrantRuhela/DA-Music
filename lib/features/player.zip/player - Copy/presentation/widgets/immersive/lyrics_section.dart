import 'package:flutter/material.dart';
import '../../../../../core/extensions/context_extensions.dart';
import '../../../../../app/theme/tokens.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../../shared/providers/player_providers.dart';

class LyricsSection extends ConsumerWidget {
  const LyricsSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colors = context.daColors;
    final typography = context.daTypography;
    final currentSong = ref.watch(currentSongProvider);

    final List<String> lyricsList = (currentSong?.lyrics != null && currentSong!.lyrics!.trim().isNotEmpty)
        ? currentSong.lyrics!.split('\n')
        : ['Lyrics unavailable.'];

    return Container(
      height: 160.0,
      constraints: const BoxConstraints(maxWidth: 600.0),
      margin: const EdgeInsets.symmetric(horizontal: DATokens.spacingLarge),
      decoration: BoxDecoration(
        color: colors.surfaceCard.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(DATokens.radiusLarge),
        border: Border.all(
          color: colors.border.withValues(alpha: 0.5),
          width: 1.0,
        ),
      ),
      child: Stack(
        children: [
          // Scrollable Lyrics List
          ScrollConfiguration(
            behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                vertical: DATokens.spacingMedium,
                horizontal: DATokens.spacingLarge,
              ),
              physics: const BouncingScrollPhysics(),
              itemCount: lyricsList.length,
              itemBuilder: (context, index) {
                final isActive = index == 2;
                final color = isActive
                    ? colors.primary
                    : colors.textSecondary.withValues(alpha: 0.6);

                final style = isActive
                    ? typography.body.copyWith(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 16.0,
                      )
                    : typography.body.copyWith(
                        color: color,
                        fontSize: 14.0,
                      );

                return Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: DATokens.spacingTiny + 2.0,
                  ),
                  child: Center(
                    child: Text(
                      lyricsList[index],
                      style: style,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                );
              },
            ),
          ),

          // Top Fade Gradient Overlay
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 32.0,
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      colors.surface.withValues(alpha: 0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Bottom Fade Gradient Overlay
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 32.0,
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      colors.surface.withValues(alpha: 0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
