import 'package:flutter/material.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../../app/theme/tokens.dart';
import 'expand_button.dart';
import '../../../../shared/widgets/da_icon_button.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../shared/providers/player_providers.dart';

class PlayerHeader extends ConsumerWidget {
  const PlayerHeader({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colors = context.daColors;
    final typography = context.daTypography;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Now Playing',
          style: typography.title.copyWith(color: colors.textPrimary),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ExpandButton(
              onPressed: () => ref.read(immersiveModeProvider.notifier).state = true,
            ),
            const SizedBox(width: DATokens.spacingTiny),
            DAIconButton(
              icon: Icons.more_horiz_outlined,
              tooltip: 'More options',
              onPressed: () {},
            ),
          ],
        ),
      ],
    );
  }
}
