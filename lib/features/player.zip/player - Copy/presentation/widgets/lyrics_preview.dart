import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../../app/theme/tokens.dart';
import '../../../../shared/widgets/da_card.dart';
import '../../../../shared/providers/player_providers.dart';

class LyricsPreview extends ConsumerWidget {
  const LyricsPreview({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colors = context.daColors;
    final typography = context.daTypography;
    final currentSong = ref.watch(currentSongProvider);

    final List<String> lyricsList = (currentSong?.lyrics != null && currentSong!.lyrics!.trim().isNotEmpty)
        ? currentSong.lyrics!.split('\n')
        : ['Lyrics unavailable.'];

    return Expanded(
      child: DACard(
        isHoverable: false,
        padding: const EdgeInsets.all(DATokens.spacingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'LYRICS PREVIEW',
                  style: typography.caption.copyWith(
                    color: colors.primary,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.0,
                  ),
                ),
                Icon(
                  Icons.lyrics_outlined,
                  size: DATokens.iconSmall,
                  color: colors.primary,
                ),
              ],
            ),
            const SizedBox(height: DATokens.spacingSmall),
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.zero,
                physics: const BouncingScrollPhysics(),
                itemCount: lyricsList.length,
                itemBuilder: (context, index) {
                  final isActive = index == 2;
                  final color = isActive
                      ? colors.primary
                      : colors.textSecondary.withValues(alpha: 0.6);

                  final style = isActive
                      ? typography.body.copyWith(
                          color: color,
                          fontWeight: FontWeight.bold,
                          fontSize: 14.0,
                        )
                      : typography.body.copyWith(
                          color: color,
                          fontSize: 13.0,
                        );

                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      vertical: DATokens.spacingTiny + 1.0,
                    ),
                    child: Text(
                      lyricsList[index],
                      style: style,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
